package com.playgroundonline.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

private val Coral = Color(0xFFFF6B61)
private val Blue = Color(0xFF356BFF)
private val Yellow = Color(0xFFFFD34E)
private val Ink = Color(0xFF20243A)
private val Bg = Color(0xFFFFF8F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PlaygroundApp() }
    }
}

private enum class Tab(val title: String) { Home("Главная"), Editor("Песочница"), Community("Сообщество"), Profile("Профиль"), Settings("Настройки") }

@Composable
private fun PlaygroundApp() {
    var tab by remember { mutableStateOf(Tab.Home) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Coral, secondary = Blue, tertiary = Yellow, background = Bg, surface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val icons = listOf(Icons.Default.Home, Icons.Default.Code, Icons.Default.Groups, Icons.Default.Person, Icons.Default.Settings)
                Tab.values().forEachIndexed { i, t -> NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(icons[i], t.title) }, label = { Text(t.title, fontSize = 10.sp) }) }
            }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    Tab.Home -> HomePage(onEditor = { tab = Tab.Editor }, onCommunity = { tab = Tab.Community })
                    Tab.Editor -> WebsiteSandbox()
                    Tab.Community -> CommunityPage()
                    Tab.Profile -> ProfilePage()
                    Tab.Settings -> SettingsPage()
                }
            }
        }
    }
}

@Composable private fun Page(title: String, subtitle: String, body: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp)); Text(title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(subtitle, color = Ink.copy(alpha = .65f), fontSize = 13.sp); Spacer(Modifier.height(14.dp)); body()
    }
}

@Composable private fun HomePage(onEditor: () -> Unit, onCommunity: () -> Unit) {
    Page("Playground Online", "Создавай сайты прямо на телефоне ✨") {
        Card(colors = CardDefaults.cardColors(containerColor = Coral)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text("MAKE · TEST · SHARE", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Твоя идея может стать сайтом!", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp)); Button(onClick = onEditor, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Coral)) { Icon(Icons.Default.Code, null); Spacer(Modifier.width(8.dp)); Text("Открыть песочницу") }
            }
        }
        Spacer(Modifier.height(16.dp)); Text("Быстрый доступ", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp)); Button(onClick = onEditor, modifier = Modifier.fillMaxWidth()) { Text("＋ Создать сайт") }
        OutlinedButton(onClick = onCommunity, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Groups, null); Spacer(Modifier.width(8.dp)); Text("Открыть сообщество") }
        Text("Файлы редактора хранятся на этом устройстве.", color = Ink.copy(alpha = .6f), fontSize = 12.sp)
    }
}

@Composable private fun WebsiteSandbox() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val folder = remember { File(context.filesDir, "web_projects").apply { mkdirs() } }
    var files by remember { mutableStateOf(folder.listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList()) }
    var selected by remember { mutableStateOf(files.firstOrNull() ?: "index.html") }
    var code by remember { mutableStateOf("") }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("style.css") }
    var preview by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Файлы сохраняются на телефоне") }
    fun load(name: String) { selected = name; code = File(folder, name).takeIf { it.exists() }?.readText() ?: starter(name); preview = false }
    LaunchedEffect(Unit) { if (files.isEmpty()) { File(folder, "index.html").writeText(starter("index.html")); files = listOf("index.html") }; load(files.firstOrNull() ?: "index.html") }
    Page("Песочница сайта", "Создавай файлы, редактируй код и проверяй результат") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null); Text("Файл") }
            OutlinedButton(onClick = { File(folder, selected).writeText(code); status = "Сохранено: $selected" }) { Icon(Icons.Default.Save, null); Text("Сохранить") }
            Button(onClick = { File(folder, selected).writeText(code); preview = true }, enabled = selected.endsWith(".html")) { Icon(Icons.Default.PlayArrow, null); Text("Запуск") }
        }
        Spacer(Modifier.height(6.dp)); Text("Файл: $selected", fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("index.html", "style.css", "script.js").forEach { name -> TextButton(onClick = { if (File(folder, name).exists()) load(name) else { selected = name; code = starter(name) } }) { Text(name, fontSize = 10.sp) } }
        }
        if (preview) {
            TextButton(onClick = { preview = false }) { Text("← Назад к коду") }
            val html = makePreviewHtml(folder, selected, code)
            AndroidView(factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = true; webViewClient = WebViewClient(); loadDataWithBaseURL("https://playground.local/", html, "text/html", "UTF-8", null) } }, update = { it.loadDataWithBaseURL("https://playground.local/", html, "text/html", "UTF-8", null) }, modifier = Modifier.fillMaxWidth().weight(1f))
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Файлы:", fontWeight = FontWeight.Bold)
                files.take(4).forEach { name -> TextButton(onClick = { load(name) }) { Text(name, fontSize = 10.sp) } }
            }
            OutlinedTextField(value = code, onValueChange = { code = it }, modifier = Modifier.fillMaxWidth().weight(1f), label = { Text("Код файла · $selected") }, minLines = 10, textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
        }
        Text(status, fontSize = 11.sp, color = Blue)
    }
    if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, title = { Text("Создать файл") }, text = {
        Column { Text("Укажи имя и расширение файла:"); OutlinedTextField(value = newName, onValueChange = { newName = it }, singleLine = true, label = { Text("например, index.html") }) }
    }, confirmButton = { TextButton(onClick = { val clean = newName.trim().replace("/", "").replace("\\", ""); if (clean.isNotBlank()) { val f = File(folder, clean); if (!f.exists()) f.writeText(starter(clean)); files = folder.listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList(); load(clean); status = "Создан файл $clean" }; showCreate = false }) { Text("Создать") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Отмена") } })
}

private fun makePreviewHtml(folder: File, selected: String, code: String): String {
    var html = if (selected.endsWith(".html")) code else File(folder, "index.html").takeIf { it.exists() }?.readText() ?: "<h2>Создай index.html</h2>"
    val css = File(folder, "style.css").takeIf { it.exists() }?.readText().orEmpty()
    val js = File(folder, "script.js").takeIf { it.exists() }?.readText().orEmpty()
    if (css.isNotBlank()) html = html.replace(Regex("<link[^>]*href=[\"']style\\.css[\"'][^>]*>", RegexOption.IGNORE_CASE), "<style>$css</style>")
    if (js.isNotBlank()) html = html.replace(Regex("<script[^>]*src=[\"']script\\.js[\"'][^>]*></script>", RegexOption.IGNORE_CASE), "<script>$js</script>")
    return html
}

private fun starter(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "html" -> "<!doctype html>\n<html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Мой сайт</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><h1>Привет, мир!</h1><p>Мой первый сайт в Playground Online.</p><button onclick=\"hello()\">Нажми меня</button><script src=\"script.js\"></script></body></html>"
    "css" -> "body { font-family: sans-serif; padding: 24px; background: #fff8f2; }\nh1 { color: #ff6b61; }\nbutton { padding: 12px 18px; border: 0; border-radius: 12px; background: #356bff; color: white; }"
    "js" -> "function hello() { alert('Привет из Playground!'); }"
    "json" -> "{\n  \"name\": \"My website\"\n}"
    else -> ""
}

@Composable private fun CommunityPage() { Page("Сообщество", "Пока это локальный демонстрационный раздел") { Text("Здесь позже появятся публикации пользователей после подключения базы данных."); } }
@Composable private fun ProfilePage() { Page("Профиль", "Твоя учётная запись") { Text("Войди через Firebase в разделе Настройки."); } }

@Composable private fun SettingsPage() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("auth", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("apiKey", "") ?: "") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var signedEmail by remember { mutableStateOf(prefs.getString("email", null)) }
    var message by remember { mutableStateOf("Для входа создай Firebase-проект и включи Authentication → Email/Password.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Page("Firebase вход", "Регистрация и авторизация по email") {
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Firebase Web API Key") }, singleLine = true)
        OutlinedTextField(value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Электронная почта") }, singleLine = true)
        OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Пароль (от 6 символов)") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { prefs.edit().putString("apiKey", apiKey.trim()).apply(); if (apiKey.isBlank() || email.isBlank() || password.length < 6) { message = "Проверь API-ключ, email и пароль (минимум 6 символов)." } else { busy = true; scope.launch { val result = withContext(Dispatchers.IO) { firebaseAuth(apiKey.trim(), email.trim(), password, false) }; busy = false; result.onSuccess { signedEmail = email.trim(); prefs.edit().putString("email", signedEmail).putString("token", it).apply(); message = "Вход выполнен!" }.onFailure { message = it.message ?: "Ошибка входа" } } } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text(if (busy) "Подождите…" else "Войти") }
        OutlinedButton(onClick = { prefs.edit().putString("apiKey", apiKey.trim()).apply(); if (apiKey.isBlank() || email.isBlank() || password.length < 6) message = "Проверь API-ключ, email и пароль." else { busy = true; scope.launch { val result = withContext(Dispatchers.IO) { firebaseAuth(apiKey.trim(), email.trim(), password, true) }; busy = false; result.onSuccess { signedEmail = email.trim(); prefs.edit().putString("email", signedEmail).putString("token", it).apply(); message = "Аккаунт создан и вход выполнен!" }.onFailure { message = it.message ?: "Ошибка регистрации" } } } }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("Создать аккаунт") }
        Text(message, color = Blue, fontSize = 12.sp)
        signedEmail?.let { Text("Вошли как: $it", fontWeight = FontWeight.Bold); TextButton(onClick = { prefs.edit().remove("email").remove("token").apply(); signedEmail = null; message = "Вы вышли из аккаунта." }) { Text("Выйти") } }
        Spacer(Modifier.height(12.dp)); Text("Где взять ключ: Firebase Console → Project settings → General → Your apps → Web API Key. В Authentication включи Email/Password.", fontSize = 12.sp, color = Ink.copy(alpha = .7f))
    }
}

private fun firebaseAuth(apiKey: String, email: String, password: String, signUp: Boolean): Result<String> = runCatching {
    val endpoint = if (signUp) "signUp" else "signInWithPassword"
    val conn = (URL("https://identitytoolkit.googleapis.com/v1/accounts:$endpoint?key=$apiKey").openConnection() as HttpURLConnection).apply { requestMethod = "POST"; doOutput = true; connectTimeout = 15000; readTimeout = 15000; setRequestProperty("Content-Type", "application/json") }
    conn.outputStream.use { it.write(JSONObject().put("email", email).put("password", password).put("returnSecureToken", true).toString().toByteArray()) }
    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
    val body = stream.bufferedReader().use { it.readText() }; val json = JSONObject(body)
    if (conn.responseCode !in 200..299) throw IllegalStateException(json.optJSONObject("error")?.optString("message") ?: "Firebase request failed (${conn.responseCode})")
    json.getString("idToken")
}
